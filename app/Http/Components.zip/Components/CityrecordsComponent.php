<?php 

namespace App\Http\Components;

use App\Models\User;
use App\Models\City;
use App\Models\CityRecord;
use Illuminate\Support\Facades\DB;

class CityrecordsComponent
{
    public static function getdata($name = "")
    {
        $data = DB::table('cities as c')->leftJoin('city_records as cr', 'cr.city_id', '=', 'c.id');
        if($name) {
            $data =City::whereIn("'name','like','%'.$name.'%' as city");
        }
        return $data->paginate(10);
    
    }
    public static function getweather(){
        $data = DB::table('city_records')->groupBy('weather_condition')->pluck('weather_condition');
        return $data;
    }

}
?>